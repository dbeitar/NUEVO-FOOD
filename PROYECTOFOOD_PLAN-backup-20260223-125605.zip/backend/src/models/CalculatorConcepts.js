// Datos temporales - conceptos de calculadora (factores de cálculo)
const calculatorConcepts = [
  {
    id: 1,
    nombre: 'Factor Actividad - Sedentario',
    tipo: 'factor_actividad',
    valor: 1.2,
    descripcion: 'Poco o ningún ejercicio',
    activo: true,
  },
  {
    id: 2,
    nombre: 'Factor Actividad - Leve',
    tipo: 'factor_actividad',
    valor: 1.375,
    descripcion: 'Ejercicio 1-3 días/semana',
    activo: true,
  },
  {
    id: 3,
    nombre: 'Factor Actividad - Moderado',
    tipo: 'factor_actividad',
    valor: 1.55,
    descripcion: 'Ejercicio 4-5 días/semana',
    activo: true,
  },
  {
    id: 4,
    nombre: 'Factor Actividad - Intenso',
    tipo: 'factor_actividad',
    valor: 1.725,
    descripcion: 'Ejercicio 6-7 días/semana',
    activo: true,
  },
  {
    id: 5,
    nombre: 'Proteína - Pérdida Grasa',
    tipo: 'distribucion_macro',
    valor: 2.2,
    descripcion: 'g proteína por kg peso (pérdida grasa)',
    activo: true,
  },
  {
    id: 6,
    nombre: 'Proteína - Mantenimiento',
    tipo: 'distribucion_macro',
    valor: 1.6,
    descripcion: 'g proteína por kg peso (mantenimiento)',
    activo: true,
  },
  {
    id: 7,
    nombre: 'Proteína - Ganancia Muscular',
    tipo: 'distribucion_macro',
    valor: 2.0,
    descripcion: 'g proteína por kg peso (ganancia)',
    activo: true,
  },
];

module.exports = calculatorConcepts;
